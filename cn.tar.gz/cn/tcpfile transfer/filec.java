import java.io.*;
import java.net.*;
class filec
{
		public static void main(String[] args) throws IOException
		{
			Socket sc;
			sc = new Socket("127.0.0.1",8000);
			byte []contents=new byte [10000];
			File file=new File("lols");
			FileOutputStream fs = new FileOutputStream(file);
			BufferedOutputStream bs= new BufferedOutputStream(fs);
			InputStream is = sc.getInputStream();
			int bytesRead = 0; 
        	while((bytesRead=is.read(contents))!=-1)
            	bs.write(contents, 0, bytesRead);
            bs.flush();
            sc.close(); 

		}
}
//InetAddress.getNameBy("localhost")