import java.io.DataInputStream;
 
import java.io.DataOutputStream; 
import java.io.IOException; 
import java.net.ServerSocket; 
import java.net.Socket; 

public class Server 
{ 
    public static void main(String args[]) throws IOException 
    { 
  
        // Step 1: Establish the socket connection. 
        ServerSocket ss = new ServerSocket(3017); 
        Socket s = ss.accept(); 
        double result=0;
  
        // Step 2: Processing the request. 
        DataInputStream dis = new DataInputStream(s.getInputStream()); 
        DataOutputStream dos = new DataOutputStream(s.getOutputStream()); 
  
        while (true) 
        { 
        	double degrees;
        	double deg;
            
            String input = dis.readUTF(); 
           
            degrees=Integer.parseInt(input);
            deg=degrees*3.14159/180;
            
            result=Math.sin(deg); 
            
     
            System.out.println("Equation received:" + input); 
            
            
            dos.writeUTF(Double.toString(result)); 
            
        }
        /*s.close();
		dos.close();
		dis.close();*/
		
    } 
} 
