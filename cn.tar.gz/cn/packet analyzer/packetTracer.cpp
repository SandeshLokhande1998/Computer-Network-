#include<iostream>
#include<fstream>
using namespace std;

int main(){

    ifstream fin;
    fin.open("data.csv");     //open in read mode

    string protocol;
    int tcp=0,arp=0,udp=0,dns=0,http=0;

    while(fin.good()){              //good to iterate to end of file
        getline(fin,protocol,',');      //returns the text till next ,
        protocol=string(protocol,1,protocol.length()-2);       //remove inverted commas from the word
        if(protocol=="TCP")
            tcp++;
        if(protocol=="ARP")
            arp++;
        if(protocol=="DNS")
            dns++;
        if(protocol=="UDP")
            udp++;
        if(protocol=="HTTP")
            http++;
    }

    cout<<"TCP: "<<tcp<<endl;
    cout<<"ARP: "<<arp<<endl;
    cout<<"DNS: "<<dns<<endl;
    cout<<"UDP: "<<udp<<endl;
    cout<<"HTTP: "<<http<<endl;
    fin.close();
    return 0;
}
