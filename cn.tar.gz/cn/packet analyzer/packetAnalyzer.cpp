#include<iostream>
#include<fstream>
using namespace std;

int main(){

    int count=0;           //to have the count of the type of packet asked
    ifstream fin;
    string srNo,time,source,destination,protocol,len,info;
    char choice;
    string protocolChoice;

    do{
        cout<<"\nSelect which protocol packets you want to see "<<endl;
        cout<<"1. TCP"<<endl;
        cout<<"2. UDP"<<endl;
        cout<<"3. ARP"<<endl;
        cout<<"4. DNS"<<endl;
        cout<<"5. HTTP"<<endl;
        cout<<"q. Quit"<<endl;
        cin>>choice;
        count=0;       //reinitialize
        switch(choice){
            case '1':
                protocolChoice="TCP";
                break;
            case '2':
                protocolChoice="UDP";
                break;
            case '3':
                protocolChoice="ARP";
                break;
            case '4':
                protocolChoice="DNS";
                break;
            case '5':
                protocolChoice="HTTP";
                break;
        }
        fin.open("data.csv");     //open in read mode


        while(fin.good()){

            getline(fin,srNo,',');
            getline(fin,time,',');
            getline(fin,source,',');
            getline(fin,destination,',');
            getline(fin,protocol,',');
            getline(fin,len,',');
            getline(fin,info,'\n');

            protocol=string(protocol,1,protocol.length()-2);

            if(protocol==protocolChoice){     //=="Protocol" just to print the headings in the csv file

                if(count==0)
                    cout<<"No.\tTime\t\tSource\t\tDestination\tProtocol Length"<<endl;
                cout<<endl;
                cout<<string(srNo,1,srNo.length()-2)<<"\t";
                cout<<string(time,1,time.length()-2)<<"\t";
                cout<<string(source,1,source.length()-2)<<"\t";
                cout<<string(destination,1,destination.length()-2)<<"\t";
                cout<<protocol<<"\t";
                cout<<string(len,1,len.length()-2)<<"\t";
                cout<<endl;
                count++;
            }
        }

        cout<<"\n Total packets of "<<protocolChoice<<" are: "<<count<<endl;
        fin.close();    //close and open again inside dowhile to reset pointer to start
    }
    while(choice!='q');

    fin.close();
    return 0;
}
