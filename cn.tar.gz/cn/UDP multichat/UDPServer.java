
import java.io.*;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class UDPServer {
	int port;
	
	DatagramSocket serverSocket  = null;
	ExecutorService pool = null;
	int connCount = 0;
	
	public static void main(String[] args) {
		
		UDPServer serverObject = new UDPServer(5000);
		serverObject.startServer();
	}
	
	public UDPServer(int port) { // constructor
		this.port = port;
		pool = Executors.newFixedThreadPool(5);
	}

	private void startServer() {
		try {
			 serverSocket = new DatagramSocket(5000); //Java DatagramSocket class represents a connection-less socket for sending and receiving datagram packets. Usage - (Port_No)
			System.out.println("Server booted.");
			System.out.println("Any client can send -1 to stop the server.");
			
			//while (true)
			{
				
				connCount++;
				ServerThreadBody runnable = new ServerThreadBody(serverSocket, connCount, this);
				pool.execute(runnable);
			}			
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
class ServerThreadBody implements Runnable {
	
	UDPServer server = null;
	DatagramSocket serverSocket  = null;
	BufferedReader inFromUser=null;
	int id;
	
	public ServerThreadBody(DatagramSocket serverSocket , int connCount, UDPServer udpServer) {
		// TODO Auto-generated constructor stub
		this.serverSocket = serverSocket;
		this.id = id;
		this.server = server;
		inFromUser = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nConnection " + id + " established with: " + serverSocket);
		System.out.println("Server is Ready.");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
                        byte[] receiveData = new byte[1024];
                        byte[] sendData = new byte[1024];
                        byte[] buf = new byte[1024];
			DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
			receivePacket.setData(buf);
			try {
				serverSocket.receive(receivePacket);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String sentence = new String(receivePacket.getData());
			System.out.println("\nRECEIVED: " + sentence);

			InetAddress IPAddress = receivePacket.getAddress();
			int port = receivePacket.getPort();
 
			System.out.println("\nREPLY :");
			String reply = null;
			try {
				reply = inFromUser.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			sendData = reply.getBytes();
			
			DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, port);
			try {
				serverSocket.send(sendPacket);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// Send Capitalized data back to client
		}
	}
}
