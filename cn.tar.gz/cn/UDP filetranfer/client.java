
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class client {
	private String sourceFilePath = null;
	private String destinationPath = null;
	BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));

	public void createConnection() {
		try {

			DatagramSocket socket = new DatagramSocket();
			InetAddress ia = InetAddress.getByName("localhost");
			
			FileEvent event = getFileEvent();
			
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			ObjectOutputStream os = new ObjectOutputStream(outputStream);
			os.writeObject(event);
			byte[] data = outputStream.toByteArray(); //getting data using this function
			DatagramPacket sendPacket = new DatagramPacket(data, data.length,ia, 9876);
			socket.send(sendPacket);
			System.out.println("File sent from client");
			
			byte[] incomingData = new byte[1024];
			DatagramPacket incomingPacket = new DatagramPacket(incomingData, incomingData.length);
			socket.receive(incomingPacket);
			String response = new String(incomingPacket.getData());
			System.out.println("Response from server:" + response);
			Thread.sleep(2000);
			System.exit(0);

		} catch (IOException|InterruptedException e) {
			e.printStackTrace();
		}
	}

	public FileEvent getFileEvent() throws IOException {
		FileEvent fileEvent = new FileEvent();
		
		System.out.print("Enter Source File Path:");
		sourceFilePath=bf.readLine();
		System.out.print("Enter Destination File Path:");
		destinationPath=bf.readLine();
		
		String fileName = sourceFilePath.substring(sourceFilePath.lastIndexOf("/") + 1, sourceFilePath.length());
		String path = destinationPath.substring(0, destinationPath.lastIndexOf("/") + 1);
		
		fileEvent.setDestinationDirectory(path);
		fileEvent.setFilename(fileName);
		fileEvent.setSourceDirectory(sourceFilePath);
		
		File file = new File(sourceFilePath);
		
		if (file.isFile()) {
			try {
				DataInputStream dis = new DataInputStream(new FileInputStream(file));
				long len = (int) file.length();
				byte[] fileBytes = new byte[(int) len];
				int read = 0;
				int numRead = 0;
				while (read < fileBytes.length && (numRead = dis.read(fileBytes, read, fileBytes.length - read)) >= 0) {
					read = read + numRead;
				}
				fileEvent.setFileSize(len);
				fileEvent.setFileData(fileBytes);
				fileEvent.setStatus("Success");
			} catch (Exception e) {
				e.printStackTrace();
				fileEvent.setStatus("Error");
			}
		} else {
			System.out.println("path specified is not pointing to a file");
			fileEvent.setStatus("Error");
		}
		return fileEvent;
	}

	public static void main(String[] args) {
		client client = new client();
		client.createConnection();
	}
}
