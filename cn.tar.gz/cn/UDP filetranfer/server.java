
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class server {
	private FileEvent fileEvent = null;

	public void createAndListenSocket() {
		try {
			DatagramSocket socket = new DatagramSocket(9876);
			byte[] incomingData = new byte[1024 * 1000 * 50];
			while (true) {
				
				DatagramPacket incomingPacket = new DatagramPacket(incomingData, incomingData.length);
				socket.receive(incomingPacket);
				byte[] data = incomingPacket.getData();
				ByteArrayInputStream in = new ByteArrayInputStream(data);
				ObjectInputStream is = new ObjectInputStream(in);
				fileEvent = (FileEvent) is.readObject();
				if (fileEvent.getStatus().equalsIgnoreCase("Error")) {
					System.out.println("Some issue happened while packing the data @ client side");
					System.exit(0);
				}
				
				createAndWriteFile(); // writing the file to hard disk
				
				InetAddress ia = incomingPacket.getAddress();
				int port = incomingPacket.getPort();
				String reply = "Thank you for the message";
				byte[] outgoingData = reply.getBytes();
				DatagramPacket replyPacket = new DatagramPacket(outgoingData, outgoingData.length, ia, port);
				socket.send(replyPacket);
				Thread.sleep(3000);
				System.exit(0);

			}

		} catch (IOException|ClassNotFoundException|InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void createAndWriteFile() {
		String outputFile = fileEvent.getDestinationDirectory() + fileEvent.getFilename();
		if (!new File(fileEvent.getDestinationDirectory()).exists()) {
			new File(fileEvent.getDestinationDirectory()).mkdirs();
		}
		File dstFile = new File(outputFile);
		try {
			FileOutputStream fos = new FileOutputStream(dstFile);
			fos.write(fileEvent.getFileData());
			fos.flush();
			fos.close();
			System.out.println("Output file : " + outputFile + " is successfully saved ");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		server server = new server();
		server.createAndListenSocket();
	}
}
